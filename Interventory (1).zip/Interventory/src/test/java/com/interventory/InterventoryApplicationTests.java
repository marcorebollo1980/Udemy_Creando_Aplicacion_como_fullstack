package com.interventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
